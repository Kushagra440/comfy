from django.apps import AppConfig


class MywebappConfig(AppConfig):
    name = 'mywebapp'
